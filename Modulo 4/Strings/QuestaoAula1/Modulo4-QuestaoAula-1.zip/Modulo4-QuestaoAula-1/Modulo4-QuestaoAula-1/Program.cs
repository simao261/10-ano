﻿Console.Write("Insira o seu nome: ");
string nome = Console.ReadLine();
Console.WriteLine();
Console.WriteLine(nome.ToUpper());
Console.ReadKey();