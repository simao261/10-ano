﻿//// ex 1
//class Pogram
//{
//    static void Main(string[] args)
//    {
//        asteriscos(3);
//        Console.WriteLine("\n");
//        asteriscos(5);
//        Console.WriteLine("\n");
//        asteriscos(7);
//        Console.WriteLine("\n");
//        asteriscos(5);
//        Console.WriteLine("\n");
//        asteriscos(3);
//        Console.WriteLine("\n");


//    }
//    static void asteriscos(int x)
//    {
//        int i;
//        for (i = 1; i <= x; i++)
//        {
//            Console.Write("*");
//        }
//        Console.WriteLine("\n");
//        Console.ReadKey();
//    }
//}

// ex 2



class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Insira o Primeiro Numero:");
        int num1 = int.Parse(Console.ReadLine());

        Console.WriteLine("Insira o segundo Numero:");
        int num2 = int.Parse(Console.ReadLine());

        int maiorNumero = Math.Max(num1, num2);
        int menorNumero = Math.Min(num1, num2);

        int somaPares = 0;

        for (int i = menorNumero + 1; i < maiorNumero; i++)
        {
            if (i % 2 == 0)
            {
                somaPares += i;
            }
        }

        Console.WriteLine($"A soma dos números pares entre {menorNumero} e {maiorNumero} é: {somaPares}");
        Console.ReadKey();
    }
}





