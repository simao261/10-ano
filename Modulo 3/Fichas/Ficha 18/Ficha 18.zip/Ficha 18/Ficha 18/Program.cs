﻿// ex 1.1

float peso, altura, IMC;

Console.WriteLine("Insira a altura (Metros)");
altura = float.Parse(Console.ReadLine());
Console.WriteLine("Insira o peso (Kg)");
peso = float.Parse(Console.ReadLine());

IMC = peso / (altura * altura);

Console.WriteLine("IMC= " + IMC);

if (IMC <= 18.5)
{
    Console.WriteLine("Baixo Peso ");
}
else if (IMC <= 24.9)
{
    Console.WriteLine("Peso Normal ");
}
else if (IMC <= 29.9)
{
    Console.WriteLine("Pré-Obesidade ");
}

else if (IMC <= 34.9)
{
    Console.WriteLine("Obesidade Grau I ");
}

else if (IMC <= 39.9)
{
    Console.WriteLine("Obesidade Grau II ");
}


else
    Console.WriteLine("Obesidade Grau III ");

Console.ReadKey();

// ex 1.2

Console.WriteLine("insira o volume de vendas do vendedor");
int VolumedeVendas = Convert.ToInt32(Console.ReadLine());

if (VolumedeVendas <= 3000)
{
    Console.WriteLine("Fraco Vendedor");
}

else if (VolumedeVendas >= 3001 && VolumedeVendas <= 4500)
{
    Console.WriteLine("Vendedor Médio");
}

else if (VolumedeVendas >= 4501 && VolumedeVendas <= 7000)
{
    Console.WriteLine("Bom Vendedor");
}

else
{
    Console.WriteLine("Ótimo Vendedor");
}

Console.ReadKey();

// ex 1.3


Console.WriteLine("Indique o Primeiro Número");
int num1 = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Indique o Segundo Número");
int num2 = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Indique o Terceiro Número");
int num3 = Convert.ToInt32(Console.ReadLine());

// 1.4

Console.WriteLine("insira o seu Salário Bruto");
double SalarioBruto = Convert.ToDouble(Console.ReadLine());

double imposto = 0;

if (SalarioBruto < 1000)
{
    imposto = SalarioBruto * 0.05;
}

else if (SalarioBruto >= 1000 && SalarioBruto < 5000)
{
    imposto = SalarioBruto * 0.11;
}

else
{
    imposto = SalarioBruto * 0.35;
}

double salarioliquido = SalarioBruto - imposto;

Console.WriteLine($"O salário líquido é: {salarioliquido}€");
Console.WriteLine($"O imposto a pagar é: {imposto}€");

Console.ReadKey();

// ex 1.6

Console.WriteLine("insira uma hora do dia");
int hora = Convert.ToInt32(Console.ReadLine());

if (hora >= 5 && hora < 8)
{
    Console.WriteLine("Madrugada");
}

else if (hora >= 8 && hora < 13)
{
    Console.WriteLine("Manha");
}

else if (hora >= 13 && hora < 19)
{
    Console.WriteLine("Tarde");
}

else
{
    Console.WriteLine("Noite");
}
Console.ReadKey();


/* falta acabar de fazer o 1.4,1.7 e 1.5 foi onde tive mais dificuldade*/
